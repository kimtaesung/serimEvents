-- Inquiries Table Migration
-- This script creates the inquiries table for storing customer inquiries/consultations
-- MySQL 8.0+

-- Inquiries Table (문의 정보)
CREATE TABLE IF NOT EXISTS inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone_number VARCHAR(20) NOT NULL,
    manager_name VARCHAR(100) NOT NULL,
    manager_address VARCHAR(255),
    table_number INT,
    product_type VARCHAR(100),
    consultation_contents LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    has_agreement BOOLEAN DEFAULT FALSE,
    status ENUM('pending', 'reviewed', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Verify table creation
SELECT 'Inquiries table created successfully' AS status;
