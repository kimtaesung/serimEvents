# SerimRobo 가비아 배포 가이드

이 폴더는 가비아 호스팅에 배포할 프로덕션 파일들을 포함합니다.

## 📁 폴더 구조

```
gabiaPublish/
├── public_html/          # React 빌드 결과물 (정적 파일)
├── server/               # Node.js 서버 코드
│   ├── database/         # 데이터베이스 설정 및 스키마
│   ├── routes/           # API 라우트
│   ├── uploads/          # 업로드된 파일들
│   └── index.js          # 메인 서버 파일
├── logs/                 # PM2 로그 파일 (자동 생성)
├── uploads/              # 미디어 파일 저장소
├── package.json          # 프로젝트 의존성
└── ecosystem.config.js   # PM2 프로덕션 설정
```

## 🚀 배포 단계

### 1. 파일 업로드
이 폴더의 모든 파일을 가비아 호스팅 서버에 업로드합니다.

### 2. 의존성 설치
```bash
cd /path/to/gabiaPublish
npm install --production
```

### 3. 환경 변수 설정
`.env` 파일을 생성하고 다음 변수들을 설정합니다:

```env
# 데이터베이스
DB_HOST=db.storm566.gabia.io
DB_PORT=3306
DB_NAME=serimrobo
DB_USER=storm566
DB_PASSWORD=your_password_here

# 포트 설정
PORT=8007

# JWT 토큰
JWT_SECRET=your_jwt_secret_here

# 관리자 계정
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
ADMIN_EMAIL=admin@serimrobo.com

# 배포 환경
NODE_ENV=production
```

### 4. PM2로 서버 시작
```bash
pm2 start ecosystem.config.js --env production
```

### 5. PM2 자동 시작 설정 (선택사항)
```bash
pm2 startup
pm2 save
```

## 📋 서버 관리 명령어

```bash
# 서버 상태 확인
pm2 status

# 로그 보기
pm2 logs serimrobo

# 서버 재시작
pm2 restart serimrobo

# 서버 중지
pm2 stop serimrobo
```

## 🗄️ 데이터베이스

MySQL 데이터베이스가 필요합니다. 스키마는 `server/database/schema.sql`에 있습니다.

```bash
mysql -h db.storm566.gabia.io -u storm566 -p serimrobo < server/database/schema.sql
```

## 📦 파일 크기

- `public_html/`: ~5.5 MB (React 빌드 결과)
- `server/`: ~200 KB (서버 코드)
- 총 크기: ~6 MB

## ⚠️ 주의사항

1. `.env` 파일은 서버에만 존재해야 하며, 버전 관리에 포함되지 않습니다.
2. `uploads/` 폴더는 쓰기 권한이 필요합니다.
3. 환경 변수의 패스워드는 안전하게 보관하세요.
4. 첫 배포 시 데이터베이스 초기화가 필요합니다.

## 🔧 트러블슈팅

**포트가 이미 사용 중인 경우:**
```bash
pm2 kill
# 또는 다른 포트 사용
```

**데이터베이스 연결 오류:**
- 환경 변수의 DB_HOST, DB_USER, DB_PASSWORD 확인
- 가비아 방화벽 설정 확인

**PM2 프로세스가 계속 죽는 경우:**
```bash
pm2 logs serimrobo
# 로그에서 오류 메시지 확인
```